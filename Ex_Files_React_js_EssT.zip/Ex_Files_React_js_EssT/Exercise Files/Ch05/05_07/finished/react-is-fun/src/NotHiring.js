import React from 'react'

export const NotHiring = () => 
	<div>
		<p>The library is not hiring. Check back later for more info.</p>
	</div>